# DAO Platform Wireframes (Text Style)

## 1. DAO Landing Page
---------------------------------
| [Logo]   DAO Name             |
| Tagline / Mission Statement   |
| [Create Proposal] [Join DAO]  |
|-------------------------------|
| Treasury: $XX,XXX   Members: 42 |
|-------------------------------|
| Proposals | Bounties | Forum  |
---------------------------------

## 2. Member Onboarding
--------------------------
| Welcome to [DAO Name]!      |
| [Connect Wallet] [Sign up]  |
|-----------------------------|
| Invite Code (optional): [__]|
------------------------------

## 3. Proposal Editor
---------------------------------
| [Back] [Submit Proposal]    |
| Proposal Title: [__________]|
| Markdown Editor             |
| [Attach File]               |
|-----------------------------|
| [Preview] [Submit]          |
---------------------------------

## 4. Treasury Dashboard
---------------------------------
| Treasury Overview          |
| ETH: XX.XX   Tokens: XX    |
| [View Transactions]        |
| [Allocate Budget]          |
---------------------------------

## 5. Bounty Board
-------------------------------
| Bounty Title   | Reward | [Apply] |
|--------------- |------- |-------- |
| Build a dApp   | $500   | [ ]     |
| Write Docs     | $100   | [ ]     |
-------------------------------

## 6. Community Forum
-------------------------------
| [Topic Title]  (Replies)   |
|----------------------------|
| How to vote?    (3)        |
| Treasury Q1      (7)       |
-------------------------------
